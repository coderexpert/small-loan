<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class LoanRepaymentMethod extends Model
{
    protected $table = "loan_repayment_methods";
    public $timestamps=false;
}
