<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CollateralType extends Model
{
    protected $table = "collateral_types";

    public $timestamps = false;
}
