<?php
/**
 * Created by PhpStorm.
 * User: Tj
 * Date: 5/4/2017
 * Time: 1:59 PM
 */
phpinfo();